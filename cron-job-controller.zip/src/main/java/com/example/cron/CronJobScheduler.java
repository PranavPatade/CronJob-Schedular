package com.example.cron;

import com.example.cron.model.CronJob;
import com.example.cron.repository.CronJobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.ScheduledFuture;

@Component
public class CronJobScheduler {

    @Autowired
    private CronJobService cronJobService;

    @Autowired
    private CronJobRepository repository;

    private final TaskScheduler scheduler;
    private final Map<String, ScheduledFuture<?>> scheduledTasks = new HashMap<>();

    public CronJobScheduler() {
        ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
        threadPoolTaskScheduler.setPoolSize(5);
        threadPoolTaskScheduler.setThreadNamePrefix("cron-task-");
        threadPoolTaskScheduler.initialize();
        this.scheduler = threadPoolTaskScheduler;
    }

    @PostConstruct
    public void scheduleAllJobs() {
        List<CronJob> jobs = repository.findAll();
        for (CronJob job : jobs) {
            scheduleJob(job);
        }
    }

    public void scheduleJob(CronJob job) {
        if (job.isEnabled() && job.getCronExpression() != null) {
            ScheduledFuture<?> future = scheduler.schedule(
                () -> cronJobService.runJob(job),
                new CronTrigger(job.getCronExpression())
            );
            scheduledTasks.put(job.getName(), future);
        }
    }

    public void unscheduleJob(String jobName) {
        ScheduledFuture<?> future = scheduledTasks.get(jobName);
        if (future != null) {
            future.cancel(false);
            scheduledTasks.remove(jobName);
        }
    }

    public void rescheduleJob(CronJob job) {
        unscheduleJob(job.getName());
        scheduleJob(job);
    }
}
