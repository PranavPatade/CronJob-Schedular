package com.example.cron;

import com.example.cron.model.CronJob;
import com.example.cron.repository.CronJobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class CronJobService {

    @Autowired
    private CronJobRepository repository;

    @Autowired
    private CronJobScheduler scheduler;

    private final RestTemplate restTemplate = new RestTemplate();

    public List<CronJob> getAllJobs() {
        return repository.findAll();
    }

    public void runJob(CronJob job) {
        if (job.isEnabled()) {
            try {
                restTemplate.getForObject(job.getUrl(), String.class);
                System.out.println("Executed: " + job.getName());
            } catch (Exception e) {
                System.err.println("Failed to execute: " + job.getName() + " -> " + e.getMessage());
            }
        }
    }

    public void enableJob(String name) {
        repository.findById(name).ifPresent(job -> {
            job.setEnabled(true);
            repository.save(job);
            scheduler.rescheduleJob(job);
        });
    }

    public void disableJob(String name) {
        repository.findById(name).ifPresent(job -> {
            job.setEnabled(false);
            repository.save(job);
            scheduler.unscheduleJob(job.getName());
        });
    }

    public void runAllEnabledJobs() {
        repository.findAll().stream().filter(CronJob::isEnabled).forEach(this::runJob);
    }
}
