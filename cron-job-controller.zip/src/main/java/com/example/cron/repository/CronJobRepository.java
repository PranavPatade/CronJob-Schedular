package com.example.cron.repository;

import com.example.cron.model.CronJob;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CronJobRepository extends JpaRepository<CronJob, String> {
}
