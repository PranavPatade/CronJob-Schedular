package com.example.cron.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CronJob {
    @Id
    private String name;
    private String url;
    private String cronExpression;
    private boolean enabled;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }

    public String getCronExpression() { return cronExpression; }
    public void setCronExpression(String cronExpression) { this.cronExpression = cronExpression; }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
}
