package com.example.cron;

import com.example.cron.model.CronJob;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cron")
public class CronJobController {

    @Autowired
    private CronJobService service;

    @GetMapping("/list")
    public List<CronJob> listAll() {
        return service.getAllJobs();
    }

    @GetMapping("/run/{name}")
    public String runJob(@PathVariable String name) {
        service.getAllJobs().stream()
                .filter(job -> job.getName().equalsIgnoreCase(name))
                .findFirst()
                .ifPresent(service::runJob);
        return "Triggered " + name;
    }

    @GetMapping("/runAll")
    public String runAll() {
        service.runAllEnabledJobs();
        return "Triggered all enabled jobs.";
    }

    @GetMapping("/enable/{name}")
    public String enableJob(@PathVariable String name) {
        service.enableJob(name);
        return name + " enabled.";
    }

    @GetMapping("/disable/{name}")
    public String disableJob(@PathVariable String name) {
        service.disableJob(name);
        return name + " disabled.";
    }
}
